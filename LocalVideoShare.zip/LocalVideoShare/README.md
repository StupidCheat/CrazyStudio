# Local Video Share (iOS)

Reproductor AVPlayer + servidor HTTP local (Network.framework) + código QR.
Sin dependencias externas. iOS 16 o superior.

## Compilar
- GitHub Actions: sube el proyecto (o el zip con `build-ipa-from-zip.yml`) y descarga el `.ipa` sin firmar.
  Instálalo con AltStore, Sideloadly u otra herramienta de sideload.
- Mac: `brew install xcodegen && xcodegen generate && open LocalVideoShare.xcodeproj`
  (elige tu equipo en Signing & Capabilities).

## Info.plist (ya incluido en project.yml)
- NSLocalNetworkUsageDescription
- NSBonjourServices = [_http._tcp]
- NSAppTransportSecurity > NSAllowsArbitraryLoads = true
- UIBackgroundModes = [audio]
