import SwiftUI
import AVKit

struct ContentView: View {
    @StateObject private var vm = ServerViewModel()

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    playerCard
                    linkCard
                    serverCard
                }
                .padding()
            }
            .navigationTitle("Local Video Share")
            .navigationBarTitleDisplayMode(.inline)
        }
    }

    // MARK: Reproductor

    private var playerCard: some View {
        VideoPlayer(player: vm.player)
            .aspectRatio(16.0 / 9.0, contentMode: .fit)
            .clipShape(RoundedRectangle(cornerRadius: 12))
    }

    // MARK: Enlace

    private var linkCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Enlace del video").font(.headline)
            TextField("https://…/video.mp4", text: $vm.urlString, axis: .vertical)
                .lineLimit(1...3)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .keyboardType(.URL)
                .padding(10)
                .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 10))
            Button {
                vm.loadVideo()
            } label: {
                Label("Cargar video", systemImage: "arrow.clockwise")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.bordered)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    // MARK: Servidor

    private var serverCard: some View {
        VStack(spacing: 12) {
            Button {
                vm.toggleServer()
            } label: {
                Label(vm.isRunning ? "Detener servidor" : "Iniciar servidor",
                      systemImage: vm.isRunning ? "stop.circle.fill" : "play.circle.fill")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .tint(vm.isRunning ? .red : .green)
            .controlSize(.large)

            Text(vm.status)
                .font(.footnote)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)

            if vm.isRunning {
                if let url = vm.serverURL {
                    VStack(spacing: 4) {
                        Text("IP local").font(.caption).foregroundStyle(.secondary)
                        Text(vm.localIP ?? "—").font(.title3.monospaced())
                        Text(url)
                            .font(.callout.monospaced())
                            .textSelection(.enabled)
                            .multilineTextAlignment(.center)
                    }

                    if let qr = vm.qrImage {
                        Image(uiImage: qr)
                            .interpolation(.none)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 220, height: 220)
                            .padding(12)
                            .background(.white, in: RoundedRectangle(cornerRadius: 12))
                    }

                    HStack(spacing: 12) {
                        Button("Copiar URL") { UIPasteboard.general.string = url }
                        if let shareURL = URL(string: url) {
                            ShareLink(item: shareURL)
                        }
                    }
                    .buttonStyle(.bordered)

                    Text(vm.statsText)
                        .font(.footnote.monospacedDigit())
                        .foregroundStyle(.secondary)
                } else {
                    Label("Conéctate a una red Wi-Fi para obtener la IP", systemImage: "wifi.slash")
                        .foregroundStyle(.orange)
                }
            }

            Divider()

            Toggle("Mantener activo en segundo plano", isOn: $vm.keepAlive)
            Text("Reproduce audio silencioso para que iOS no suspenda el servidor al bloquear la pantalla.")
                .font(.caption2)
                .foregroundStyle(.secondary)
        }
        .padding()
        .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 14))
    }
}
