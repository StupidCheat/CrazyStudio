import AVFoundation

/// Reproduce silencio en bucle para que iOS no suspenda la app (modo audio en segundo plano).
final class KeepAlive {
    private let engine = AVAudioEngine()
    private let node = AVAudioPlayerNode()
    private var running = false

    init() {
        engine.attach(node)
    }

    func start() {
        guard !running else { return }
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playback, mode: .default, options: [.mixWithOthers])
            try session.setActive(true)

            let format = AVAudioFormat(standardFormatWithSampleRate: 44_100, channels: 1)!
            engine.connect(node, to: engine.mainMixerNode, format: format)

            let frames: AVAudioFrameCount = 44_100
            let buffer = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: frames)!
            buffer.frameLength = frames
            if let channel = buffer.floatChannelData?[0] {
                memset(channel, 0, Int(frames) * MemoryLayout<Float>.size)
            }

            try engine.start()
            node.scheduleBuffer(buffer, at: nil, options: .loops, completionHandler: nil)
            node.play()
            running = true
        } catch {
            print("KeepAlive error: \(error)")
        }
    }

    func stop() {
        guard running else { return }
        node.stop()
        engine.stop()
        running = false
    }
}
