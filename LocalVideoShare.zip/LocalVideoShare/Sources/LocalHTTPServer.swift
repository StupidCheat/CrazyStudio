import Foundation
import Network

/// Servidor HTTP embebido (Network.framework, sin dependencias externas).
///
/// Rutas:
///   /            página web con el reproductor
///   /video.mp4   proxy en streaming hacia el enlace original (con soporte de Range)
final class LocalHTTPServer {
    enum Event {
        case ready
        case failed(String)
    }

    let queue = DispatchQueue(label: "LocalHTTPServer")
    var onEvent: ((Event) -> Void)?

    private var listener: NWListener?
    private var clients: [ObjectIdentifier: ClientConnection] = [:]   // solo se toca en `queue`

    private let lock = NSLock()
    private var _upstream: URL?
    private var _bytes: Int64 = 0
    private var _clientCount = 0

    var upstream: URL? {
        get { lock.lock(); defer { lock.unlock() }; return _upstream }
        set { lock.lock(); _upstream = newValue; lock.unlock() }
    }

    func stats() -> (bytes: Int64, clients: Int) {
        lock.lock(); defer { lock.unlock() }
        return (_bytes, _clientCount)
    }

    fileprivate func addBytes(_ n: Int) {
        lock.lock(); _bytes += Int64(n); lock.unlock()
    }

    // MARK: - Ciclo de vida

    func start(port: UInt16) throws {
        try queue.sync {
            stopOnQueue()
            guard let p = NWEndpoint.Port(rawValue: port) else {
                throw NSError(domain: "LocalHTTPServer", code: 1,
                              userInfo: [NSLocalizedDescriptionKey: "Puerto inválido"])
            }
            let params = NWParameters.tcp
            params.allowLocalEndpointReuse = true
            let l = try NWListener(using: params, on: p)
            // Anunciar por Bonjour también dispara el aviso de permiso de red local
            l.service = NWListener.Service(name: "Local Video Share", type: "_http._tcp")
            l.stateUpdateHandler = { [weak self] state in
                guard let self else { return }
                switch state {
                case .ready:
                    self.onEvent?(.ready)
                case .failed(let error):
                    self.onEvent?(.failed(error.localizedDescription))
                    self.stopOnQueue()
                default:
                    break
                }
            }
            l.newConnectionHandler = { [weak self] connection in
                self?.accept(connection)
            }
            listener = l
            l.start(queue: queue)
        }
    }

    func stop() {
        queue.async { [weak self] in self?.stopOnQueue() }
    }

    private func stopOnQueue() {
        listener?.cancel()
        listener = nil
        let all = Array(clients.values)
        clients.removeAll()
        updateClientCount()
        all.forEach { $0.close() }
    }

    private func accept(_ connection: NWConnection) {
        let client = ClientConnection(conn: connection, server: self)
        clients[ObjectIdentifier(client)] = client
        updateClientCount()
        client.start()
    }

    fileprivate func remove(_ client: ClientConnection) {
        clients[ObjectIdentifier(client)] = nil
        updateClientCount()
    }

    private func updateClientCount() {
        lock.lock(); _clientCount = clients.count; lock.unlock()
    }
}

// MARK: - Conexión de un cliente

fileprivate final class ClientConnection {
    private let conn: NWConnection
    private weak var server: LocalHTTPServer?
    private let queue: DispatchQueue

    private var buffer = Data()
    private var closed = false
    private var finishing = false

    private var task: URLSessionDataTask?
    private var session: URLSession?
    private var headOnly = false

    private var pending = 0
    private var upstreamSuspended = false

    init(conn: NWConnection, server: LocalHTTPServer) {
        self.conn = conn
        self.server = server
        self.queue = server.queue
    }

    func start() {
        conn.stateUpdateHandler = { [weak self] state in
            switch state {
            case .failed, .cancelled: self?.close()
            default: break
            }
        }
        conn.start(queue: queue)
        receiveHead()
    }

    func close() {
        guard !closed else { return }
        closed = true
        task?.cancel(); task = nil
        session?.invalidateAndCancel(); session = nil
        conn.cancel()
        server?.remove(self)
    }

    // MARK: Lectura de la petición

    private func receiveHead() {
        conn.receive(minimumIncompleteLength: 1, maximumLength: 16 * 1024) { [weak self] data, _, isComplete, error in
            guard let self, !self.closed else { return }
            if let data { self.buffer.append(data) }
            if let range = self.buffer.range(of: Data("\r\n\r\n".utf8)) {
                let head = String(decoding: self.buffer.subdata(in: 0..<range.lowerBound), as: UTF8.self)
                self.handle(head: head)
            } else if error != nil || isComplete || self.buffer.count > 64 * 1024 {
                self.close()
            } else {
                self.receiveHead()
            }
        }
    }

    private func handle(head: String) {
        let lines = head.components(separatedBy: "\r\n")
        let parts = (lines.first ?? "").split(separator: " ")
        guard parts.count >= 2 else { return respond(status: 400, text: "Petición inválida") }

        let method = String(parts[0]).uppercased()
        let path = String(parts[1]).components(separatedBy: "?").first ?? "/"

        var headers: [String: String] = [:]
        for line in lines.dropFirst() {
            if let idx = line.firstIndex(of: ":") {
                let key = line[..<idx].lowercased()
                let value = line[line.index(after: idx)...].trimmingCharacters(in: .whitespaces)
                headers[key] = value
            }
        }

        guard method == "GET" || method == "HEAD" else {
            return respond(status: 405, text: "Método no permitido")
        }
        headOnly = (method == "HEAD")

        switch path {
        case "/", "/index.html":
            respond(status: 200, text: ClientConnection.indexHTML, contentType: "text/html; charset=utf-8")
        case "/video.mp4":
            proxy(rangeHeader: headers["range"])
        default:
            respond(status: 404, text: "No encontrado")
        }
    }

    // MARK: Respuestas simples

    private func respond(status: Int, text: String, contentType: String = "text/plain; charset=utf-8") {
        let body = Data(text.utf8)
        let head = "HTTP/1.1 \(status) \(ClientConnection.reason(status))\r\n" +
            "Content-Type: \(contentType)\r\n" +
            "Content-Length: \(body.count)\r\n" +
            "Cache-Control: no-cache\r\n" +
            "Connection: close\r\n\r\n"
        var out = Data(head.utf8)
        if !headOnly { out.append(body) }
        send(out)
        finish()
    }

    // MARK: Proxy en streaming hacia el enlace original

    private func proxy(rangeHeader: String?) {
        guard let upstream = server?.upstream else {
            return respond(status: 404, text: "No hay video configurado")
        }
        var request = URLRequest(url: upstream)
        request.httpMethod = "GET"
        request.timeoutInterval = 30
        request.setValue("identity", forHTTPHeaderField: "Accept-Encoding")
        request.setValue(
            "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1",
            forHTTPHeaderField: "User-Agent")
        if let rangeHeader { request.setValue(rangeHeader, forHTTPHeaderField: "Range") }

        let delegate = ProxyDelegate(client: self, queue: queue)
        let s = URLSession(configuration: .ephemeral, delegate: delegate, delegateQueue: nil)
        session = s
        let t = s.dataTask(with: request)
        task = t
        t.resume()
    }

    fileprivate func upstreamDidRespond(_ http: HTTPURLResponse) {
        guard !closed else { return }
        let status = http.statusCode
        var contentType = http.value(forHTTPHeaderField: "Content-Type") ?? "video/mp4"
        if (status == 200 || status == 206), !contentType.lowercased().hasPrefix("video/") {
            contentType = "video/mp4"   // el origen a veces responde application/octet-stream
        }
        var head = "HTTP/1.1 \(status) \(ClientConnection.reason(status))\r\n"
        head += "Content-Type: \(contentType)\r\n"
        if let length = http.value(forHTTPHeaderField: "Content-Length") { head += "Content-Length: \(length)\r\n" }
        if let range = http.value(forHTTPHeaderField: "Content-Range") { head += "Content-Range: \(range)\r\n" }
        head += "Accept-Ranges: bytes\r\n"
        head += "Access-Control-Allow-Origin: *\r\n"
        head += "Cache-Control: no-cache\r\n"
        head += "Connection: close\r\n\r\n"
        send(Data(head.utf8))

        if headOnly {
            task?.cancel()
            finish()
        }
    }

    fileprivate func upstreamDidReceive(_ data: Data) {
        guard !closed, !headOnly else { return }
        send(data)
    }

    fileprivate func upstreamDidComplete() {
        guard !closed else { return }
        finish()
    }

    // MARK: Envío con control de flujo

    private func send(_ data: Data) {
        guard !closed else { return }
        pending += data.count
        conn.send(content: data, completion: .contentProcessed { [weak self] error in
            guard let self else { return }
            self.pending -= data.count
            self.server?.addBytes(data.count)
            if error != nil {
                self.close()
                return
            }
            if self.upstreamSuspended && self.pending < 1_000_000 {
                self.upstreamSuspended = false
                self.task?.resume()
            }
        })
        // Si el cliente es más lento que el origen, pausamos la descarga para no llenar la RAM
        if pending > 4_000_000 && !upstreamSuspended {
            upstreamSuspended = true
            task?.suspend()
        }
    }

    private func finish() {
        guard !closed, !finishing else { return }
        finishing = true
        conn.send(content: nil, contentContext: .finalMessage, isComplete: true,
                  completion: .contentProcessed { [weak self] _ in self?.close() })
    }

    // MARK: Utilidades

    private static func reason(_ code: Int) -> String {
        switch code {
        case 200: return "OK"
        case 206: return "Partial Content"
        case 301: return "Moved Permanently"
        case 302: return "Found"
        case 400: return "Bad Request"
        case 401: return "Unauthorized"
        case 403: return "Forbidden"
        case 404: return "Not Found"
        case 405: return "Method Not Allowed"
        case 416: return "Range Not Satisfiable"
        case 500: return "Internal Server Error"
        default: return "Status"
        }
    }

    private static let indexHTML = """
    <!doctype html><html><head><meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Local Video Share</title>
    <style>body{margin:0;background:#000;color:#eee;font-family:-apple-system,sans-serif}
    video{width:100%;max-height:92vh;background:#000}p{padding:12px;margin:0}a{color:#8ab4f8}</style></head>
    <body><video controls autoplay playsinline src="/video.mp4"></video>
    <p>Transmitiendo desde un iPhone &middot; <a href="/video.mp4">enlace directo</a></p></body></html>
    """
}

// MARK: - Delegado de URLSession (hilo propio -> salta a la cola del servidor)

fileprivate final class ProxyDelegate: NSObject, URLSessionDataDelegate {
    private weak var client: ClientConnection?
    private let queue: DispatchQueue

    init(client: ClientConnection, queue: DispatchQueue) {
        self.client = client
        self.queue = queue
    }

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask,
                    didReceive response: URLResponse,
                    completionHandler: @escaping (URLSession.ResponseDisposition) -> Void) {
        if let http = response as? HTTPURLResponse {
            let c = client
            queue.async { c?.upstreamDidRespond(http) }
        }
        completionHandler(.allow)
    }

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
        let c = client
        queue.async { c?.upstreamDidReceive(data) }
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        let c = client
        queue.async { c?.upstreamDidComplete() }
    }
}
