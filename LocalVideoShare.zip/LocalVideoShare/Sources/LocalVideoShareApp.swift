import SwiftUI

@main
struct LocalVideoShareApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
