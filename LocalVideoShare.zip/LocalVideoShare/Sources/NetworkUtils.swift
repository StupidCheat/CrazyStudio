import Foundation
import Darwin

enum NetworkUtils {
    /// IPv4 local del iPhone. Prioridad: Wi-Fi (en0) > hotspot personal (bridge100) > otras.
    static func localIPAddress() -> String? {
        var found: [String: String] = [:]
        var ifaddrPtr: UnsafeMutablePointer<ifaddrs>?
        guard getifaddrs(&ifaddrPtr) == 0, let first = ifaddrPtr else { return nil }
        defer { freeifaddrs(ifaddrPtr) }

        var cursor: UnsafeMutablePointer<ifaddrs>? = first
        while let current = cursor {
            let ifa = current.pointee
            let flags = Int32(ifa.ifa_flags)
            let isUp = (flags & (IFF_UP | IFF_RUNNING)) == (IFF_UP | IFF_RUNNING)
            let isLoopback = (flags & IFF_LOOPBACK) != 0

            if let addr = ifa.ifa_addr,
               addr.pointee.sa_family == UInt8(AF_INET),
               isUp, !isLoopback {
                var host = [CChar](repeating: 0, count: Int(NI_MAXHOST))
                let result = getnameinfo(addr, socklen_t(addr.pointee.sa_len),
                                         &host, socklen_t(host.count),
                                         nil, 0, NI_NUMERICHOST)
                if result == 0 {
                    found[String(cString: ifa.ifa_name)] = String(cString: host)
                }
            }
            cursor = ifa.ifa_next
        }

        for name in ["en0", "bridge100", "en1", "en2", "en3"] {
            if let ip = found[name] { return ip }
        }
        return nil
    }
}
