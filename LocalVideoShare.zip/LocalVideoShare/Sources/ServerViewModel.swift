import SwiftUI
import AVKit
import UIKit

@MainActor
final class ServerViewModel: ObservableObject {
    static let defaultURL = "https://megadl.boats/download/SPMUND-18LA.mp4?download_token=ZJHDKwqj4flVsJ5qBqX5PLPKL56pjwan7aX5yu7vgR0JESiKEHZ0bQEEowqGGEcNAmuc5KUfkDeEbRuLGxKKbD0UF2InQFjgpLKAlW1Si8kKxgc0qzLGpHBmvRNmJdkndYt1Rvfgvzj088dx0uMCOe65k4jwS56pjwaD88dx0uacKqu1lDntJQSRnT1K3GU88dx0uk6fP56pjwaM10Yp88dx0uTS88dx0uAfm1y0"

    @Published var urlString: String = ServerViewModel.defaultURL
    @Published private(set) var isRunning = false
    @Published private(set) var localIP: String?
    @Published private(set) var serverURL: String?
    @Published private(set) var qrImage: UIImage?
    @Published private(set) var status = "Servidor detenido"
    @Published private(set) var statsText = ""
    @Published var keepAlive = true {
        didSet { applyKeepAlive() }
    }

    let player = AVPlayer()
    let port: UInt16 = 8080

    private let server = LocalHTTPServer()
    private let silentAudio = KeepAlive()
    private var timer: Timer?
    private var lastBytes: Int64 = 0

    init() {
        loadVideo()
    }

    // MARK: - Video

    func loadVideo() {
        let trimmed = urlString.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let url = URL(string: trimmed),
              let scheme = url.scheme?.lowercased(),
              scheme == "http" || scheme == "https" else {
            status = "El enlace no es válido"
            return
        }
        player.replaceCurrentItem(with: AVPlayerItem(url: url))
        server.upstream = url
        if !isRunning { status = "Video cargado" }
    }

    // MARK: - Servidor

    func toggleServer() {
        if isRunning { stopServer() } else { startServer() }
    }

    private func startServer() {
        loadVideo()
        server.onEvent = { [weak self] event in
            Task { @MainActor in self?.handle(event) }
        }
        do {
            try server.start(port: port)
        } catch {
            status = "No se pudo iniciar: \(error.localizedDescription)"
            return
        }
        isRunning = true
        status = "Servidor activo en el puerto \(port)"
        lastBytes = 0
        UIApplication.shared.isIdleTimerDisabled = true
        refreshNetwork()
        applyKeepAlive()
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] _ in
            Task { @MainActor in self?.tick() }
        }
    }

    private func stopServer(message: String = "Servidor detenido") {
        server.stop()
        timer?.invalidate()
        timer = nil
        silentAudio.stop()
        UIApplication.shared.isIdleTimerDisabled = false
        isRunning = false
        statsText = ""
        status = message
    }

    private func handle(_ event: LocalHTTPServer.Event) {
        switch event {
        case .ready:
            break
        case .failed(let message):
            stopServer(message: "Error del servidor: \(message)")
        }
    }

    private func applyKeepAlive() {
        if isRunning && keepAlive { silentAudio.start() } else { silentAudio.stop() }
    }

    // MARK: - Red y estadísticas

    private func refreshNetwork() {
        let ip = NetworkUtils.localIPAddress()
        let url = ip.map { "http://\($0):\(port)/" }
        if ip != localIP { localIP = ip }
        if url != serverURL {
            serverURL = url
            qrImage = url.flatMap { QRCode.image(from: $0) }
        }
    }

    private func tick() {
        refreshNetwork()
        let s = server.stats()
        let mbps = Double(s.bytes - lastBytes) / 1_048_576
        lastBytes = s.bytes
        statsText = String(format: "Clientes: %d · Enviando %.2f MB/s", s.clients, mbps)
    }
}
