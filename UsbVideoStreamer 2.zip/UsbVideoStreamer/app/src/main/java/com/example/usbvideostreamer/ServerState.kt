package com.example.usbvideostreamer

import android.net.Uri
import android.os.SystemClock
import java.net.URLEncoder

/** Descarga en curso: se guarda en la memoria y, a la vez, se sirve por /live/. */
class DownloadSession(val url: String, val name: String) {
    @Volatile var total: Long = -1            // -1 = el servidor de origen no informa el tamaño
    @Volatile var written: Long = 0
    @Volatile var speedBps: Double = 0.0
    @Volatile var ready: Boolean = false      // archivo creado y listo para leer
    @Volatile var finished: Boolean = false
    @Volatile var cancelled: Boolean = false
    @Volatile var failed: String? = null
    @Volatile var docUri: Uri? = null
    @Volatile var endTime: Long = 0
    val startTime: Long = SystemClock.elapsedRealtime()

    val mime: String
        get() = if (name.lowercase().endsWith(".mkv")) "video/x-matroska" else "video/mp4"

    val isDone: Boolean
        get() = finished || cancelled || failed != null

    fun averageBps(): Double {
        val end = if (endTime > 0) endTime else SystemClock.elapsedRealtime()
        val sec = maxOf(1L, end - startTime) / 1000.0
        return written / sec
    }
}

/** Estado compartido entre la Activity, el servicio y el servidor HTTP. */
object ServerState {
    @Volatile var videos: List<VideoItem> = emptyList()
    @Volatile var port: Int = 8080
    @Volatile var token: String = ""      // vacío = sin clave
    @Volatile var running: Boolean = false
    @Volatile var lastError: String? = null
    @Volatile var download: DownloadSession? = null

    fun keyQuery(): String = if (token.isEmpty()) "" else "?key=$token"

    fun encode(s: String): String = URLEncoder.encode(s, "UTF-8").replace("+", "%20")

    fun videoPath(v: VideoItem): String = "/v/${v.id}/${encode(v.name)}${keyQuery()}"

    fun livePath(d: DownloadSession): String = "/live/${encode(d.name)}${keyQuery()}"
}
