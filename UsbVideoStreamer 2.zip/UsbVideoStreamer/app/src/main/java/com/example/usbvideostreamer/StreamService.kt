package com.example.usbvideostreamer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import android.provider.DocumentsContract
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Mantiene vivo el servidor HTTP y ejecuta la descarga "guardar en la memoria + transmitir".
 */
class StreamService : Service() {

    private var server: VideoStreamServer? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null

    private val nm: NotificationManager
        get() = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                ServerState.download?.takeIf { !it.isDone }?.cancelled = true
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_CANCEL_DOWNLOAD -> {
                ServerState.download?.takeIf { !it.isDone }?.cancelled = true
                return START_NOT_STICKY
            }
        }

        createChannel()
        val type = if (Build.VERSION.SDK_INT >= 29)
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK or ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        else 0
        ServiceCompat.startForeground(
            this, NOTIF_ID, buildNotification("Servidor activo en el puerto ${ServerState.port}"), type
        )

        if (!ensureServer()) return START_NOT_STICKY
        if (intent?.action == ACTION_DOWNLOAD) startDownload(intent)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        ServerState.download?.takeIf { !it.isDone }?.cancelled = true
        try { server?.stop() } catch (_: Exception) {}
        server = null
        releaseLocks()
        ServerState.running = false
        super.onDestroy()
    }

    private fun ensureServer(): Boolean {
        if (server != null) return true
        return try {
            server = VideoStreamServer(applicationContext, ServerState.port).also {
                it.start(SOCKET_READ_TIMEOUT, false)
            }
            acquireLocks()
            ServerState.running = true
            ServerState.lastError = null
            true
        } catch (e: Exception) {
            ServerState.lastError = "No se pudo iniciar el servidor (¿puerto ocupado?): ${e.message}"
            ServerState.running = false
            stopSelf()
            false
        }
    }

    // ---------- Descarga ----------

    private fun startDownload(intent: Intent) {
        val url = intent.getStringExtra(EXTRA_URL) ?: return
        val name = intent.getStringExtra(EXTRA_NAME) ?: "video.mp4"
        val tree = Uri.parse(intent.getStringExtra(EXTRA_TREE) ?: return)

        val current = ServerState.download
        if (current != null && !current.isDone) {
            ServerState.lastError = "Ya hay una descarga en curso"
            return
        }
        val session = DownloadSession(url, name)
        ServerState.download = session
        Thread({ runDownload(session, tree) }, "downloader").start()
    }

    private fun runDownload(s: DownloadSession, tree: Uri) {
        var conn: HttpURLConnection? = null
        var pfd: android.os.ParcelFileDescriptor? = null
        var out: FileOutputStream? = null
        var docUri: Uri? = null
        try {
            conn = openConnection(s.url)
            val len = conn.contentLengthLong
            s.total = if (len > 0) len else -1

            val parent = DocumentsContract.buildDocumentUriUsingTree(
                tree, DocumentsContract.getTreeDocumentId(tree)
            )
            // octet-stream: el proveedor respeta el nombre tal cual (no agrega extensión)
            docUri = DocumentsContract.createDocument(
                contentResolver, parent, "application/octet-stream", s.name
            ) ?: throw IOException("No se pudo crear el archivo en el destino")
            pfd = contentResolver.openFileDescriptor(docUri, "w")
                ?: throw IOException("No se pudo abrir el archivo para escribir")
            out = FileOutputStream(pfd.fileDescriptor)
            s.docUri = docUri
            s.ready = true

            val input = conn.inputStream
            val buf = ByteArray(256 * 1024)
            var lastT = SystemClock.elapsedRealtime()
            var lastW = 0L
            var lastNotif = lastT

            while (!s.cancelled) {
                val n = input.read(buf)
                if (n < 0) break
                out.write(buf, 0, n)
                s.written += n

                val now = SystemClock.elapsedRealtime()
                if (now - lastT >= 500) {
                    val inst = (s.written - lastW) * 1000.0 / (now - lastT)
                    s.speedBps = if (s.speedBps == 0.0) inst else s.speedBps * 0.5 + inst * 0.5
                    lastT = now
                    lastW = s.written
                }
                if (now - lastNotif >= 1000) {
                    updateNotification(s)
                    lastNotif = now
                }
            }

            try { out.flush(); out.fd.sync() } catch (_: Exception) {}
            out.close(); out = null
            pfd.close(); pfd = null

            if (s.cancelled) {
                deleteQuietly(docUri)
            } else {
                if (s.total > 0 && s.written < s.total) {
                    throw IOException("La conexión se cerró antes de terminar")
                }
                s.speedBps = 0.0
                s.endTime = SystemClock.elapsedRealtime()
                s.finished = true
            }
        } catch (e: Exception) {
            s.failed = e.message ?: e.javaClass.simpleName
            try { out?.close() } catch (_: Exception) {}
            try { pfd?.close() } catch (_: Exception) {}
            deleteQuietly(docUri)
        } finally {
            conn?.disconnect()
            val msg = when {
                s.failed != null -> "Error en la descarga: ${s.failed}"
                s.cancelled -> "Descarga cancelada"
                else -> "Descarga completada: ${s.name}"
            }
            try { nm.notify(NOTIF_ID, buildNotification(msg)) } catch (_: Exception) {}
        }
    }

    private fun deleteQuietly(doc: Uri?) {
        if (doc == null) return
        try { DocumentsContract.deleteDocument(contentResolver, doc) } catch (_: Exception) {}
    }

    /** Abre la conexión siguiendo redirecciones (incluso de http a https). */
    private fun openConnection(urlStr: String): HttpURLConnection {
        var u = URL(urlStr)
        repeat(6) {
            val c = u.openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 15_000
            c.readTimeout = 30_000
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) UsbVideoStreamer/2.1")
            c.setRequestProperty("Accept-Encoding", "identity")
            val code = c.responseCode
            if (code in 300..399) {
                val loc = c.getHeaderField("Location") ?: throw IOException("Redirección sin destino")
                c.disconnect()
                u = URL(u, loc)
                return@repeat
            }
            if (code !in 200..299) {
                c.disconnect()
                throw IOException("HTTP $code")
            }
            return c
        }
        throw IOException("Demasiadas redirecciones")
    }

    private fun updateNotification(s: DownloadSession) {
        val pct = if (s.total > 0) (s.written * 100 / s.total).toInt() else -1
        val speed = String.format("%.2f MB/s", s.speedBps / 1048576.0)
        val text = "Descargando ${s.name}: " + (if (pct >= 0) "$pct% · " else "") + speed
        try { nm.notify(NOTIF_ID, buildNotification(text, pct, cancelable = true)) } catch (_: Exception) {}
    }

    // ---------- Bloqueos y notificación ----------

    private fun acquireLocks() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "UsbVideoStreamer:wake").apply {
            setReferenceCounted(false)
            acquire()
        }
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        @Suppress("DEPRECATION")
        val mode = if (Build.VERSION.SDK_INT >= 29)
            WifiManager.WIFI_MODE_FULL_LOW_LATENCY
        else
            WifiManager.WIFI_MODE_FULL_HIGH_PERF
        wifiLock = wm.createWifiLock(mode, "UsbVideoStreamer:wifi").apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun releaseLocks() {
        try { wakeLock?.takeIf { it.isHeld }?.release() } catch (_: Exception) {}
        try { wifiLock?.takeIf { it.isHeld }?.release() } catch (_: Exception) {}
        wakeLock = null
        wifiLock = null
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Servidor de video", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun buildNotification(text: String, progress: Int = -1, cancelable: Boolean = false): Notification {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val openIntent = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), flags)
        val stopIntent = PendingIntent.getService(
            this, 1, Intent(this, StreamService::class.java).setAction(ACTION_STOP), flags
        )
        val b = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("USB Video Streamer")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openIntent)
            .addAction(0, "Detener", stopIntent)
        if (cancelable) {
            val cancelIntent = PendingIntent.getService(
                this, 2, Intent(this, StreamService::class.java).setAction(ACTION_CANCEL_DOWNLOAD), flags
            )
            b.addAction(0, "Cancelar descarga", cancelIntent)
            if (progress >= 0) b.setProgress(100, progress, false) else b.setProgress(0, 0, true)
        }
        return b.build()
    }

    companion object {
        const val ACTION_STOP = "com.example.usbvideostreamer.STOP"
        const val ACTION_DOWNLOAD = "com.example.usbvideostreamer.DOWNLOAD"
        const val ACTION_CANCEL_DOWNLOAD = "com.example.usbvideostreamer.CANCEL_DOWNLOAD"
        const val EXTRA_URL = "url"
        const val EXTRA_NAME = "name"
        const val EXTRA_TREE = "tree"
        private const val CHANNEL_ID = "stream_server"
        private const val NOTIF_ID = 1
        private const val SOCKET_READ_TIMEOUT = 30_000
    }
}
