package com.example.usbvideostreamer

import android.content.Context
import android.os.ParcelFileDescriptor
import fi.iki.elonen.NanoHTTPD
import java.io.ByteArrayInputStream
import java.io.FileInputStream
import java.io.InputStream

/**
 * Rutas:
 *   /                      página con todos los videos (reproductor + buscador)
 *   /playlist.m3u          lista de reproducción para VLC
 *   /v/{id}/{nombre}       stream del video con soporte de rangos (HTTP 206)
 *   /live/{nombre}         video que se está descargando ahora mismo (se sirve mientras se guarda)
 * Si hay clave configurada, todas las rutas exigen ?key=...
 */
class VideoStreamServer(
    private val context: Context,
    port: Int
) : NanoHTTPD(port) {

    override fun serve(session: IHTTPSession): Response {
        if (!authorized(session)) return plain(Response.Status.UNAUTHORIZED, "Clave incorrecta")
        val uri = session.uri
        return when {
            uri == "/" || uri == "/index.html" -> indexPage()
            uri == "/playlist.m3u" -> playlist(session)
            uri.startsWith("/v/") -> serveVideo(session)
            uri.startsWith("/live/") -> serveLive(session)
            else -> plain(Response.Status.NOT_FOUND, "No encontrado")
        }
    }

    private fun authorized(session: IHTTPSession): Boolean {
        val t = ServerState.token
        return t.isEmpty() || session.parms["key"] == t
    }

    // ---------- Página índice ----------
    private fun indexPage(): Response {
        val videos = ServerState.videos
        val kq = ServerState.keyQuery()
        val live = ServerState.download?.takeIf { it.ready && it.failed == null && !it.cancelled }
        val liveRow = if (live != null) {
            val u = ServerState.livePath(live)
            "<p>&#11015; En descarga: <a href=\"$u\">${esc(live.name)}</a> " +
                "<button onclick=\"p('$u')\">&#9654;</button></p>"
        } else ""
        val rows = videos.joinToString("") { v ->
            val u = ServerState.videoPath(v)
            "<li data-n=\"${esc(v.name.lowercase())}\"><a href=\"$u\">${esc(v.name)}</a> " +
                "<small>${formatSize(v.size)}</small> <button onclick=\"p('$u')\">&#9654;</button></li>"
        }
        val html = """<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>USB Video Streamer</title>
<style>body{font-family:sans-serif;background:#111;color:#eee;margin:0;padding:12px}a{color:#8ab4f8}
video{width:100%;max-height:50vh;background:#000}input{width:100%;padding:8px;margin:8px 0;box-sizing:border-box}
li{margin:8px 0;list-style:none}button{margin-left:8px}</style></head><body>
<h2>Videos (${videos.size})</h2><video id="pl" controls></video>
$liveRow
<p><a href="/playlist.m3u$kq">Descargar playlist.m3u (VLC)</a></p>
<input placeholder="Buscar..." oninput="f(this.value)"><ul style="padding:0">$rows</ul>
<script>function p(u){var v=document.getElementById('pl');v.src=u;v.play();window.scrollTo(0,0)}
function f(q){q=q.toLowerCase();document.querySelectorAll('li').forEach(function(l){l.style.display=l.dataset.n.indexOf(q)>=0?'':'none'})}</script>
</body></html>"""
        return newFixedLengthResponse(Response.Status.OK, "text/html; charset=utf-8", html)
    }

    // ---------- Playlist M3U ----------
    private fun playlist(session: IHTTPSession): Response {
        val host = session.headers["host"] ?: "localhost:${ServerState.port}"
        val sb = StringBuilder("#EXTM3U\n")
        for (v in ServerState.videos) {
            sb.append("#EXTINF:-1,").append(v.name).append('\n')
            sb.append("http://").append(host).append(ServerState.videoPath(v)).append('\n')
        }
        return newFixedLengthResponse(Response.Status.OK, "audio/x-mpegurl", sb.toString())
    }

    // ---------- Rangos ----------
    private class RangeSpec(val start: Long, val end: Long, val partial: Boolean)

    /** Devuelve null si el rango no es satisfacible. */
    private fun parseRange(header: String?, total: Long): RangeSpec? {
        var start = 0L
        var end = total - 1
        var partial = false
        if (header != null && header.startsWith("bytes=")) {
            val spec = header.removePrefix("bytes=").substringBefore(",").trim()
            val dash = spec.indexOf('-')
            if (dash >= 0) {
                val s = spec.substring(0, dash)
                val e = spec.substring(dash + 1)
                if (s.isEmpty()) {
                    val n = e.toLongOrNull() ?: return null
                    if (n <= 0) return null
                    start = maxOf(0L, total - n)
                } else {
                    start = s.toLongOrNull() ?: return null
                    if (e.isNotEmpty()) end = minOf(e.toLongOrNull() ?: return null, total - 1)
                }
                if (start >= total || start > end) return null
                partial = true
            }
        }
        return RangeSpec(start, end, partial)
    }

    private fun rangeResponse(
        mime: String, stream: InputStream, r: RangeSpec, length: Long, total: Long
    ): Response {
        val response = if (r.partial) {
            newFixedLengthResponse(Response.Status.PARTIAL_CONTENT, mime, stream, length).apply {
                addHeader("Content-Range", "bytes ${r.start}-${r.end}/$total")
            }
        } else {
            newFixedLengthResponse(Response.Status.OK, mime, stream, length)
        }
        response.addHeader("Accept-Ranges", "bytes")
        response.addHeader("Access-Control-Allow-Origin", "*")
        response.addHeader("Cache-Control", "no-cache")
        return response
    }

    private fun unsatisfiable(total: Long): Response =
        plain(Response.Status.RANGE_NOT_SATISFIABLE, "").apply {
            addHeader("Content-Range", "bytes */$total")
        }

    // ---------- Video guardado ----------
    private fun serveVideo(session: IHTTPSession): Response {
        val id = session.uri.split("/").getOrNull(2)?.toIntOrNull()
        val video = ServerState.videos.firstOrNull { it.id == id }
            ?: return plain(Response.Status.NOT_FOUND, "Video no encontrado")

        val pfd: ParcelFileDescriptor = try {
            context.contentResolver.openFileDescriptor(video.uri, "r")
        } catch (e: Exception) {
            null
        } ?: return plain(Response.Status.INTERNAL_ERROR, "No se pudo abrir el archivo")

        val total = pfd.statSize.takeIf { it >= 0 } ?: video.size
        if (total <= 0) {
            pfd.close()
            return plain(Response.Status.INTERNAL_ERROR, "Tamaño de archivo desconocido")
        }

        val r = parseRange(session.headers["range"], total)
        if (r == null) {
            pfd.close()
            return unsatisfiable(total)
        }
        val length = r.end - r.start + 1
        val stream: InputStream = if (session.method == Method.HEAD) {
            pfd.close()
            ByteArrayInputStream(ByteArray(0))
        } else {
            RangeInputStream(pfd, r.start, length)
        }
        return rangeResponse(video.mimeType, stream, r, length, total)
    }

    // ---------- Video en descarga (se transmite mientras se guarda) ----------
    private fun serveLive(session: IHTTPSession): Response {
        val s = ServerState.download ?: return plain(Response.Status.NOT_FOUND, "No hay descarga activa")

        var waited = 0
        while (!s.ready && s.failed == null && !s.cancelled && waited < 20_000) {
            Thread.sleep(100)
            waited += 100
        }
        if (!s.ready) return plain(Response.Status.INTERNAL_ERROR, s.failed ?: "La descarga aún no está lista")
        val docUri = s.docUri ?: return plain(Response.Status.INTERNAL_ERROR, "Archivo no disponible")

        val head = session.method == Method.HEAD
        val total = s.total

        fun openReader(): ParcelFileDescriptor? = try {
            context.contentResolver.openFileDescriptor(docUri, "r")
        } catch (e: Exception) {
            null
        }

        // Sin tamaño conocido: transmisión continua sin rangos
        if (total <= 0) {
            if (head) return newFixedLengthResponse(Response.Status.OK, s.mime, "")
            val pfd = openReader() ?: return plain(Response.Status.INTERNAL_ERROR, "No se pudo abrir el archivo")
            return newChunkedResponse(Response.Status.OK, s.mime, LiveInputStream(pfd, s, 0, Long.MAX_VALUE)).apply {
                addHeader("Accept-Ranges", "none")
                addHeader("Cache-Control", "no-cache")
            }
        }

        val r = parseRange(session.headers["range"], total) ?: return unsatisfiable(total)
        val length = r.end - r.start + 1
        val stream: InputStream = if (head) {
            ByteArrayInputStream(ByteArray(0))
        } else {
            val pfd = openReader() ?: return plain(Response.Status.INTERNAL_ERROR, "No se pudo abrir el archivo")
            LiveInputStream(pfd, s, r.start, length)
        }
        return rangeResponse(s.mime, stream, r, length, total)
    }

    private fun plain(status: Response.IStatus, msg: String): Response =
        newFixedLengthResponse(status, "text/plain", msg)

    private fun esc(s: String): String = s
        .replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        .replace("\"", "&quot;").replace("'", "&#39;")

    private fun formatSize(bytes: Long): String = when {
        bytes >= 1L shl 30 -> String.format("%.2f GB", bytes / (1L shl 30).toDouble())
        bytes >= 1L shl 20 -> String.format("%.1f MB", bytes / (1L shl 20).toDouble())
        else -> "${bytes / 1024} KB"
    }

    /** Lee solo [remaining] bytes desde [start]; cierra el descriptor al terminar. */
    private class RangeInputStream(
        private val pfd: ParcelFileDescriptor,
        start: Long,
        private var remaining: Long
    ) : InputStream() {

        private val input = FileInputStream(pfd.fileDescriptor)

        init {
            try {
                input.channel.position(start)
            } catch (e: Exception) {
                var left = start
                while (left > 0) {
                    val skipped = input.skip(left)
                    if (skipped <= 0) break
                    left -= skipped
                }
            }
        }

        override fun read(): Int {
            if (remaining <= 0) return -1
            val b = input.read()
            if (b >= 0) remaining--
            return b
        }

        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (remaining <= 0) return -1
            val n = input.read(b, off, minOf(len.toLong(), remaining).toInt())
            if (n > 0) remaining -= n
            return n
        }

        override fun available(): Int =
            minOf(input.available().toLong(), remaining).toInt()

        override fun close() {
            try { input.close() } catch (_: Exception) {}
            try { pfd.close() } catch (_: Exception) {}
        }
    }

    /**
     * Como RangeInputStream, pero el archivo todavía se está escribiendo:
     * espera a que la descarga haya escrito los bytes pedidos.
     */
    private class LiveInputStream(
        private val pfd: ParcelFileDescriptor,
        private val s: DownloadSession,
        start: Long,
        private var remaining: Long
    ) : InputStream() {

        private val input = FileInputStream(pfd.fileDescriptor)
        private var pos = start

        init {
            try { input.channel.position(start) } catch (_: Exception) {}
        }

        override fun read(): Int {
            val one = ByteArray(1)
            val n = read(one, 0, 1)
            return if (n <= 0) -1 else one[0].toInt() and 0xFF
        }

        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (remaining <= 0) return -1
            var emptyReads = 0
            while (true) {
                val avail = s.written - pos
                if (avail <= 0) {
                    if (s.finished || s.failed != null || s.cancelled) return -1
                    Thread.sleep(50)
                    continue
                }
                val n = input.read(b, off, minOf(len.toLong(), remaining, avail).toInt())
                if (n > 0) {
                    pos += n
                    remaining -= n
                    return n
                }
                if (++emptyReads > 100) return -1
                Thread.sleep(50)
            }
        }

        override fun close() {
            try { input.close() } catch (_: Exception) {}
            try { pfd.close() } catch (_: Exception) {}
        }
    }
}
