package com.example.usbvideostreamer

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.security.SecureRandom
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var listView: ListView
    private lateinit var tvStatus: TextView
    private lateinit var tvIp: TextView
    private lateinit var tvUrl: TextView
    private lateinit var tvIndex: TextView
    private lateinit var ivQr: ImageView
    private lateinit var etPort: EditText
    private lateinit var cbToken: CheckBox
    private lateinit var btnServer: Button
    private lateinit var btnCopy: Button
    private lateinit var btnCopyIndex: Button
    private lateinit var btnShare: Button
    private lateinit var btnVlc: Button

    private lateinit var prefs: SharedPreferences
    private lateinit var adapter: ArrayAdapter<String>

    private val videos = mutableListOf<VideoItem>()
    private var selected: VideoItem? = null
    private var videoUrl: String? = null
    private var indexUrl: String? = null
    private var lastQrUrl: String? = null
    private var currentTree: Uri? = null

    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    private val ticker = object : Runnable {
        override fun run() {
            refreshUi()
            mainHandler.postDelayed(this, 1000)
        }
    }

    private val storagePermission: String
        get() = if (Build.VERSION.SDK_INT >= 33)
            Manifest.permission.READ_MEDIA_VIDEO
        else
            Manifest.permission.READ_EXTERNAL_STORAGE

    private val storageLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) loadInternalVideos()
            else toast("Permiso denegado. Puedes usar la opción USB / Carpeta.")
        }

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { _ ->
            launchService() // arranca aunque se deniegue (solo se oculta la notificación)
        }

    private val folderLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { treeUri ->
            if (treeUri != null) {
                try {
                    contentResolver.takePersistableUriPermission(
                        treeUri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (_: Exception) {
                }
                prefs.edit().putString("tree", treeUri.toString()).apply()
                scanTree(treeUri)
            }
        }

    // Detecta cuando se conecta o desconecta una memoria USB
    private val mediaReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_MEDIA_MOUNTED -> {
                    toast("Almacenamiento conectado")
                    currentTree?.let { t -> mainHandler.postDelayed({ scanTree(t) }, 2000) }
                }
                Intent.ACTION_MEDIA_REMOVED,
                Intent.ACTION_MEDIA_UNMOUNTED,
                Intent.ACTION_MEDIA_EJECT,
                Intent.ACTION_MEDIA_BAD_REMOVAL -> {
                    toast("Almacenamiento desconectado")
                    currentTree?.let { t -> mainHandler.postDelayed({ scanTree(t) }, 1000) }
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("settings", Context.MODE_PRIVATE)

        listView = findViewById(R.id.listVideos)
        tvStatus = findViewById(R.id.tvStatus)
        tvIp = findViewById(R.id.tvIp)
        tvUrl = findViewById(R.id.tvUrl)
        tvIndex = findViewById(R.id.tvIndex)
        ivQr = findViewById(R.id.ivQr)
        etPort = findViewById(R.id.etPort)
        cbToken = findViewById(R.id.cbToken)
        btnServer = findViewById(R.id.btnServer)
        btnCopy = findViewById(R.id.btnCopy)
        btnCopyIndex = findViewById(R.id.btnCopyIndex)
        btnShare = findViewById(R.id.btnShare)
        btnVlc = findViewById(R.id.btnVlc)

        etPort.setText(prefs.getInt("port", 8080).toString())
        cbToken.isChecked = prefs.getBoolean("tokenOn", false)

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_single_choice, mutableListOf<String>())
        listView.adapter = adapter
        listView.isNestedScrollingEnabled = true

        findViewById<Button>(R.id.btnInternal).setOnClickListener { requestInternalVideos() }
        findViewById<Button>(R.id.btnPickFolder).setOnClickListener { folderLauncher.launch(null) }

        listView.setOnItemClickListener { _, _, position, _ ->
            selected = videos[position]
            if (!ServerState.running) startServer()
            refreshUi()
        }

        btnServer.setOnClickListener {
            if (ServerState.running) stopService(Intent(this, StreamService::class.java))
            else startServer()
        }
        btnCopy.setOnClickListener { videoUrl?.let { copy(it, "URL del video") } }
        btnCopyIndex.setOnClickListener { indexUrl?.let { copy(it, "URL de la página") } }
        btnShare.setOnClickListener { shareUrl() }
        btnVlc.setOnClickListener { openInVlc() }

        // Recordar la última carpeta/USB elegida
        prefs.getString("tree", null)?.let { s ->
            val uri = Uri.parse(s)
            if (contentResolver.persistedUriPermissions.any { it.uri == uri && it.isReadPermission }) {
                scanTree(uri)
            }
        }
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_MEDIA_MOUNTED)
            addAction(Intent.ACTION_MEDIA_REMOVED)
            addAction(Intent.ACTION_MEDIA_UNMOUNTED)
            addAction(Intent.ACTION_MEDIA_EJECT)
            addAction(Intent.ACTION_MEDIA_BAD_REMOVAL)
            addDataScheme("file")
        }
        ContextCompat.registerReceiver(this, mediaReceiver, filter, ContextCompat.RECEIVER_EXPORTED)
    }

    override fun onStop() {
        super.onStop()
        try { unregisterReceiver(mediaReceiver) } catch (_: Exception) {}
    }

    override fun onResume() {
        super.onResume()
        mainHandler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        mainHandler.removeCallbacks(ticker)
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdownNow()
        // El servidor NO se detiene aquí: sigue en el servicio hasta pulsar "Detener".
    }

    // ---------- Servidor ----------

    private fun startServer() {
        val port = etPort.text.toString().toIntOrNull()?.takeIf { it in 1024..65535 }
        if (port == null) {
            toast("Puerto inválido (usa 1024-65535)")
            return
        }
        ServerState.port = port
        ServerState.token = if (cbToken.isChecked) {
            prefs.getString("token", null) ?: randomToken().also {
                prefs.edit().putString("token", it).apply()
            }
        } else ""
        prefs.edit().putInt("port", port).putBoolean("tokenOn", cbToken.isChecked).apply()
        ServerState.videos = videos.toList()

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            launchService()
        }
    }

    private fun launchService() {
        ContextCompat.startForegroundService(this, Intent(this, StreamService::class.java))
    }

    private fun randomToken(): String {
        val chars = "abcdefghjkmnpqrstuvwxyz23456789"
        val rnd = SecureRandom()
        return (1..8).map { chars[rnd.nextInt(chars.length)] }.joinToString("")
    }

    // ---------- UI ----------

    private fun refreshUi() {
        val running = ServerState.running
        ServerState.lastError?.let { toast(it); ServerState.lastError = null }

        btnServer.text = if (running) "Detener servidor" else "Iniciar servidor"
        etPort.isEnabled = !running
        cbToken.isEnabled = !running

        val ip = NetworkUtils.getLocalIpAddress()
        tvIp.text = ip ?: "Sin conexión Wi-Fi"

        val base = if (ip != null && running) "http://$ip:${ServerState.port}" else null
        val sel = selected
        videoUrl = if (base != null && sel != null) base + ServerState.videoPath(sel) else null
        indexUrl = if (base != null) base + "/" + ServerState.keyQuery() else null

        tvUrl.text = videoUrl ?: when {
            !running -> "Inicia el servidor o elige un video"
            else -> "Elige un video de la lista"
        }
        tvIndex.text = indexUrl ?: "—"

        btnCopy.isEnabled = videoUrl != null
        btnCopyIndex.isEnabled = indexUrl != null
        btnShare.isEnabled = videoUrl != null || indexUrl != null
        btnVlc.isEnabled = videoUrl != null || indexUrl != null

        updateQr(indexUrl)
    }

    private fun updateQr(url: String?) {
        if (url == lastQrUrl) return
        lastQrUrl = url
        ivQr.setImageBitmap(url?.let { QrUtils.create(it) })
    }

    private fun copy(text: String, label: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText(label, text))
        toast("Copiado")
    }

    private fun shareUrl() {
        val url = videoUrl ?: indexUrl ?: return
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, url)
        }
        startActivity(Intent.createChooser(send, "Compartir URL"))
    }

    private fun openInVlc() {
        val url = videoUrl ?: indexUrl ?: return
        val vlc = Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(url), "video/*")
            .setPackage("org.videolan.vlc")
        try {
            startActivity(vlc)
        } catch (e: ActivityNotFoundException) {
            try {
                startActivity(
                    Intent.createChooser(
                        Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(url), "video/*"),
                        "Abrir con"
                    )
                )
            } catch (e2: ActivityNotFoundException) {
                toast("No hay reproductor disponible")
            }
        }
    }

    // ---------- Fuentes de video ----------

    private fun requestInternalVideos() {
        if (ContextCompat.checkSelfPermission(this, storagePermission) == PackageManager.PERMISSION_GRANTED) {
            loadInternalVideos()
        } else {
            storageLauncher.launch(storagePermission)
        }
    }

    private fun loadInternalVideos() {
        currentTree = null
        tvStatus.text = "Buscando videos…"
        executor.execute {
            val found = mutableListOf<VideoItem>()
            val projection = arrayOf(
                MediaStore.Video.Media._ID,
                MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.Media.SIZE
            )
            val selection = "${MediaStore.Video.Media.DISPLAY_NAME} LIKE ? OR ${MediaStore.Video.Media.DISPLAY_NAME} LIKE ?"
            val args = arrayOf("%.mp4", "%.mkv")
            try {
                contentResolver.query(
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI, projection, selection, args,
                    "${MediaStore.Video.Media.DISPLAY_NAME} ASC"
                )?.use { c ->
                    val idCol = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                    val nameCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                    val sizeCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                    while (c.moveToNext()) {
                        val uri = ContentUris.withAppendedId(
                            MediaStore.Video.Media.EXTERNAL_CONTENT_URI, c.getLong(idCol)
                        )
                        found += VideoItem(c.getString(nameCol), uri, c.getLong(sizeCol))
                    }
                }
            } catch (e: Exception) {
                mainHandler.post { toast("Error: ${e.message}") }
            }
            mainHandler.post { showVideos(found) }
        }
    }

    private fun scanTree(treeUri: Uri) {
        currentTree = treeUri
        tvStatus.text = "Escaneando carpeta…"
        executor.execute {
            val found = mutableListOf<VideoItem>()
            val rootId = DocumentsContract.getTreeDocumentId(treeUri)
            scanDir(treeUri, rootId, found, depth = 0)
            found.sortBy { it.name.lowercase() }
            mainHandler.post { showVideos(found) }
        }
    }

    private fun scanDir(treeUri: Uri, parentId: String, out: MutableList<VideoItem>, depth: Int) {
        if (depth > 5) return
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentId)
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE
        )
        try {
            contentResolver.query(childrenUri, projection, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getString(0)
                    val name = c.getString(1) ?: continue
                    val mime = c.getString(2)
                    val size = if (c.isNull(3)) 0L else c.getLong(3)
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        scanDir(treeUri, id, out, depth + 1)
                    } else {
                        val lower = name.lowercase()
                        if (lower.endsWith(".mp4") || lower.endsWith(".mkv")) {
                            out += VideoItem(name, DocumentsContract.buildDocumentUriUsingTree(treeUri, id), size)
                        }
                    }
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun showVideos(found: List<VideoItem>) {
        val numbered = found.mapIndexed { i, v -> v.copy(id = i + 1) }
        videos.clear()
        videos.addAll(numbered)
        selected = null
        listView.clearChoices()
        ServerState.videos = numbered // el servidor (si está activo) ve la lista nueva al instante
        adapter.clear()
        adapter.addAll(numbered.map { "${it.name}  (${formatSize(it.size)})" })
        adapter.notifyDataSetChanged()
        tvStatus.text = if (numbered.isEmpty()) "No se encontraron videos MP4/MKV."
        else "${numbered.size} video(s) encontrados. Toca uno para transmitir."
    }

    // ---------- Utilidades ----------

    private fun formatSize(bytes: Long): String = when {
        bytes >= 1L shl 30 -> String.format("%.2f GB", bytes / (1L shl 30).toDouble())
        bytes >= 1L shl 20 -> String.format("%.1f MB", bytes / (1L shl 20).toDouble())
        else -> "${bytes / 1024} KB"
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
