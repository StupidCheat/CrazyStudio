package com.example.usbvideostreamer

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var listView: ListView
    private lateinit var tvStatus: TextView
    private lateinit var tvIp: TextView
    private lateinit var tvUrl: TextView
    private lateinit var btnCopy: Button

    private val videos = mutableListOf<VideoItem>()
    private lateinit var adapter: ArrayAdapter<String>

    private var server: VideoStreamServer? = null
    private var currentUrl: String? = null

    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    private val storagePermission: String
        get() = if (Build.VERSION.SDK_INT >= 33)
            Manifest.permission.READ_MEDIA_VIDEO
        else
            Manifest.permission.READ_EXTERNAL_STORAGE

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) loadInternalVideos()
            else toast("Permiso denegado. Puedes usar la opción USB / Carpeta.")
        }

    private val folderLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { treeUri ->
            if (treeUri != null) {
                try {
                    contentResolver.takePersistableUriPermission(
                        treeUri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (_: Exception) {
                }
                scanTree(treeUri)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        listView = findViewById(R.id.listVideos)
        tvStatus = findViewById(R.id.tvStatus)
        tvIp = findViewById(R.id.tvIp)
        tvUrl = findViewById(R.id.tvUrl)
        btnCopy = findViewById(R.id.btnCopy)

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_single_choice, mutableListOf<String>())
        listView.adapter = adapter

        findViewById<Button>(R.id.btnInternal).setOnClickListener { requestInternalVideos() }
        // El selector del sistema muestra las memorias USB (OTG) conectadas
        findViewById<Button>(R.id.btnPickFolder).setOnClickListener { folderLauncher.launch(null) }

        listView.setOnItemClickListener { _, _, position, _ -> selectVideo(videos[position]) }

        btnCopy.setOnClickListener {
            currentUrl?.let {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("URL de video", it))
                toast("URL copiada")
            }
        }

        refreshIp()
    }

    override fun onResume() {
        super.onResume()
        refreshIp()
    }

    override fun onDestroy() {
        super.onDestroy()
        server?.stop()
        executor.shutdownNow()
    }

    // ---------- Fuentes de video ----------

    private fun requestInternalVideos() {
        if (ContextCompat.checkSelfPermission(this, storagePermission) == PackageManager.PERMISSION_GRANTED) {
            loadInternalVideos()
        } else {
            permissionLauncher.launch(storagePermission)
        }
    }

    private fun loadInternalVideos() {
        tvStatus.text = "Buscando videos…"
        executor.execute {
            val found = mutableListOf<VideoItem>()
            val projection = arrayOf(
                MediaStore.Video.Media._ID,
                MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.Media.SIZE
            )
            val selection = "${MediaStore.Video.Media.DISPLAY_NAME} LIKE ? OR ${MediaStore.Video.Media.DISPLAY_NAME} LIKE ?"
            val args = arrayOf("%.mp4", "%.mkv")
            try {
                contentResolver.query(
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI, projection, selection, args,
                    "${MediaStore.Video.Media.DISPLAY_NAME} ASC"
                )?.use { c ->
                    val idCol = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                    val nameCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                    val sizeCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                    while (c.moveToNext()) {
                        val uri = ContentUris.withAppendedId(
                            MediaStore.Video.Media.EXTERNAL_CONTENT_URI, c.getLong(idCol)
                        )
                        found += VideoItem(c.getString(nameCol), uri, c.getLong(sizeCol))
                    }
                }
            } catch (e: Exception) {
                mainHandler.post { toast("Error: ${e.message}") }
            }
            mainHandler.post { showVideos(found) }
        }
    }

    private fun scanTree(treeUri: Uri) {
        tvStatus.text = "Escaneando carpeta…"
        executor.execute {
            val found = mutableListOf<VideoItem>()
            val rootId = DocumentsContract.getTreeDocumentId(treeUri)
            scanDir(treeUri, rootId, found, depth = 0)
            found.sortBy { it.name.lowercase() }
            mainHandler.post { showVideos(found) }
        }
    }

    private fun scanDir(treeUri: Uri, parentId: String, out: MutableList<VideoItem>, depth: Int) {
        if (depth > 5) return
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentId)
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE
        )
        try {
            contentResolver.query(childrenUri, projection, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getString(0)
                    val name = c.getString(1) ?: continue
                    val mime = c.getString(2)
                    val size = if (c.isNull(3)) 0L else c.getLong(3)
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        scanDir(treeUri, id, out, depth + 1)
                    } else {
                        val lower = name.lowercase()
                        if (lower.endsWith(".mp4") || lower.endsWith(".mkv")) {
                            out += VideoItem(name, DocumentsContract.buildDocumentUriUsingTree(treeUri, id), size)
                        }
                    }
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun showVideos(found: List<VideoItem>) {
        videos.clear()
        videos.addAll(found)
        adapter.clear()
        adapter.addAll(found.map { "${it.name}  (${formatSize(it.size)})" })
        adapter.notifyDataSetChanged()
        tvStatus.text = if (found.isEmpty()) "No se encontraron videos MP4/MKV."
        else "${found.size} video(s) encontrados. Toca uno para transmitir."
    }

    // ---------- Servidor ----------

    private fun selectVideo(video: VideoItem) {
        if (server == null) {
            try {
                server = VideoStreamServer(this).also { it.start(SOCKET_READ_TIMEOUT, false) }
            } catch (e: Exception) {
                toast("No se pudo iniciar el servidor: ${e.message}")
                server = null
                return
            }
        }
        server?.currentVideo = video
        refreshIp()
        updateUrl(video)
    }

    private fun refreshIp() {
        val ip = NetworkUtils.getLocalIpAddress()
        tvIp.text = ip ?: "Sin conexión Wi-Fi"
        server?.currentVideo?.let { updateUrl(it) }
    }

    private fun updateUrl(video: VideoItem) {
        val ip = NetworkUtils.getLocalIpAddress()
        if (ip == null) {
            currentUrl = null
            tvUrl.text = "Conéctate a una red Wi-Fi"
            btnCopy.isEnabled = false
            return
        }
        val url = "http://$ip:${VideoStreamServer.DEFAULT_PORT}/video.${video.extension}"
        currentUrl = url
        tvUrl.text = url
        btnCopy.isEnabled = true
    }

    // ---------- Utilidades ----------

    private fun formatSize(bytes: Long): String = when {
        bytes >= 1L shl 30 -> String.format("%.2f GB", bytes / (1L shl 30).toDouble())
        bytes >= 1L shl 20 -> String.format("%.1f MB", bytes / (1L shl 20).toDouble())
        else -> "${bytes / 1024} KB"
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    companion object {
        private const val SOCKET_READ_TIMEOUT = 30_000
    }
}
