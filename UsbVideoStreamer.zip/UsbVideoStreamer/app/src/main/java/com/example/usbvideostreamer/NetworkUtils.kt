package com.example.usbvideostreamer

import java.net.Inet4Address
import java.net.NetworkInterface

object NetworkUtils {
    /**
     * IPv4 local. Prioridad: Wi-Fi (wlan) > hotspot (ap/swlan) > ethernet > cualquiera.
     */
    fun getLocalIpAddress(): String? {
        val candidates = mutableListOf<Pair<String, String>>() // (interfaz, ip)
        try {
            for (nif in NetworkInterface.getNetworkInterfaces()) {
                if (!nif.isUp || nif.isLoopback) continue
                for (addr in nif.inetAddresses) {
                    if (addr is Inet4Address && !addr.isLoopbackAddress && addr.isSiteLocalAddress) {
                        candidates += nif.name to (addr.hostAddress ?: continue)
                    }
                }
            }
        } catch (_: Exception) {
        }
        val order = listOf("wlan", "ap", "swlan", "eth")
        for (prefix in order) {
            candidates.firstOrNull { it.first.startsWith(prefix) }?.let { return it.second }
        }
        return candidates.firstOrNull()?.second
    }
}
