package com.example.usbvideostreamer

import java.net.Inet4Address
import java.net.NetworkInterface

object NetworkUtils {
    /** Devuelve la IPv4 local (preferencia wlan), o null si no hay red. */
    fun getLocalIpAddress(): String? {
        val candidates = mutableListOf<Pair<String, String>>() // (interfaz, ip)
        try {
            for (nif in NetworkInterface.getNetworkInterfaces()) {
                if (!nif.isUp || nif.isLoopback) continue
                for (addr in nif.inetAddresses) {
                    if (addr is Inet4Address && !addr.isLoopbackAddress && addr.isSiteLocalAddress) {
                        candidates += nif.name to (addr.hostAddress ?: continue)
                    }
                }
            }
        } catch (_: Exception) {
        }
        return (candidates.firstOrNull { it.first.startsWith("wlan") } ?: candidates.firstOrNull())?.second
    }
}
