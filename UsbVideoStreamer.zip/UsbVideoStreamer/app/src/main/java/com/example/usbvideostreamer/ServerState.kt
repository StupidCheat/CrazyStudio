package com.example.usbvideostreamer

import java.net.URLEncoder

/** Estado compartido entre la Activity, el servicio y el servidor HTTP. */
object ServerState {
    @Volatile var videos: List<VideoItem> = emptyList()
    @Volatile var port: Int = 8080
    @Volatile var token: String = ""      // vacío = sin clave
    @Volatile var running: Boolean = false
    @Volatile var lastError: String? = null

    fun keyQuery(): String = if (token.isEmpty()) "" else "?key=$token"

    fun encode(s: String): String = URLEncoder.encode(s, "UTF-8").replace("+", "%20")

    fun videoPath(v: VideoItem): String = "/v/${v.id}/${encode(v.name)}${keyQuery()}"
}
