package com.example.usbvideostreamer

import android.net.Uri

data class VideoItem(
    val name: String,
    val uri: Uri,
    val size: Long
) {
    val extension: String
        get() = name.substringAfterLast('.', "mp4").lowercase()

    val mimeType: String
        get() = if (extension == "mkv") "video/x-matroska" else "video/mp4"
}
