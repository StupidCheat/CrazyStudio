package com.example.usbvideostreamer

import android.content.Context
import android.os.ParcelFileDescriptor
import fi.iki.elonen.NanoHTTPD
import java.io.FileInputStream
import java.io.InputStream

/**
 * Servidor HTTP embebido. Sirve el video seleccionado en /video.mp4 o /video.mkv
 * con soporte de peticiones por rango (HTTP 206) para poder pausar y buscar.
 */
class VideoStreamServer(
    private val context: Context,
    port: Int = DEFAULT_PORT
) : NanoHTTPD(port) {

    @Volatile
    var currentVideo: VideoItem? = null

    override fun serve(session: IHTTPSession): Response {
        val video = currentVideo
            ?: return plain(Response.Status.NOT_FOUND, "No hay video seleccionado")

        if (!session.uri.lowercase().startsWith("/video.")) {
            return plain(Response.Status.NOT_FOUND, "Usa /video.${video.extension}")
        }

        val pfd: ParcelFileDescriptor = try {
            context.contentResolver.openFileDescriptor(video.uri, "r")
        } catch (e: Exception) {
            null
        } ?: return plain(Response.Status.INTERNAL_ERROR, "No se pudo abrir el archivo")

        val total = pfd.statSize.takeIf { it >= 0 } ?: video.size
        if (total <= 0) {
            pfd.close()
            return plain(Response.Status.INTERNAL_ERROR, "Tamaño de archivo desconocido")
        }

        var start = 0L
        var end = total - 1
        var partial = false

        val rangeHeader = session.headers["range"]
        if (rangeHeader != null && rangeHeader.startsWith("bytes=")) {
            val spec = rangeHeader.removePrefix("bytes=").substringBefore(",").trim()
            val dash = spec.indexOf('-')
            if (dash >= 0) {
                val s = spec.substring(0, dash)
                val e = spec.substring(dash + 1)
                if (s.isEmpty()) {
                    // Sufijo: últimos N bytes
                    val n = e.toLongOrNull()
                    if (n == null || n <= 0) return unsatisfiable(pfd, total)
                    start = maxOf(0L, total - n)
                } else {
                    start = s.toLongOrNull() ?: return unsatisfiable(pfd, total)
                    if (e.isNotEmpty()) {
                        end = minOf(e.toLongOrNull() ?: return unsatisfiable(pfd, total), total - 1)
                    }
                }
                if (start >= total || start > end) return unsatisfiable(pfd, total)
                partial = true
            }
        }

        val length = end - start + 1
        val stream = RangeInputStream(pfd, start, length)

        val response = if (partial) {
            newFixedLengthResponse(Response.Status.PARTIAL_CONTENT, video.mimeType, stream, length).apply {
                addHeader("Content-Range", "bytes $start-$end/$total")
            }
        } else {
            newFixedLengthResponse(Response.Status.OK, video.mimeType, stream, length)
        }
        response.addHeader("Accept-Ranges", "bytes")
        response.addHeader("Access-Control-Allow-Origin", "*")
        response.addHeader("Cache-Control", "no-cache")
        return response
    }

    private fun unsatisfiable(pfd: ParcelFileDescriptor, total: Long): Response {
        pfd.close()
        return plain(Response.Status.RANGE_NOT_SATISFIABLE, "").apply {
            addHeader("Content-Range", "bytes */$total")
        }
    }

    private fun plain(status: Response.IStatus, msg: String): Response =
        newFixedLengthResponse(status, "text/plain", msg)

    /** Lee solo [length] bytes empezando en [start]; cierra el descriptor al terminar. */
    private class RangeInputStream(
        private val pfd: ParcelFileDescriptor,
        start: Long,
        private var remaining: Long
    ) : InputStream() {

        private val input = FileInputStream(pfd.fileDescriptor)

        init {
            try {
                input.channel.position(start)
            } catch (e: Exception) {
                // Proveedor sin seek: avanzar leyendo
                var left = start
                while (left > 0) {
                    val skipped = input.skip(left)
                    if (skipped <= 0) break
                    left -= skipped
                }
            }
        }

        override fun read(): Int {
            if (remaining <= 0) return -1
            val b = input.read()
            if (b >= 0) remaining--
            return b
        }

        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (remaining <= 0) return -1
            val n = input.read(b, off, minOf(len.toLong(), remaining).toInt())
            if (n > 0) remaining -= n
            return n
        }

        override fun available(): Int =
            minOf(input.available().toLong(), remaining).toInt()

        override fun close() {
            try { input.close() } catch (_: Exception) {}
            try { pfd.close() } catch (_: Exception) {}
        }
    }

    companion object {
        const val DEFAULT_PORT = 8080
    }
}
